ENVISIONKART WEBSITE — BEGINNER SETUP
=====================================

FILES
-----
index.html  The complete website. No extra software or libraries required.

BEFORE LAUNCH
-------------
1. Open index.html in a browser to preview the site.
2. Edit index.html and find this line near the bottom:
       const WHATSAPP_NUMBER = "91XXXXXXXXXX";
3. Replace 91XXXXXXXXXX with your WhatsApp number including India's country code.
   Example format: 919876543210
   Use digits only, with no +, spaces or hyphens.
4. Replace the sample product names, prices, and emoji illustrations with your real catalogue.
   Search in index.html for sample names like "Everyday Essential Tee". Update both:
   - the product card visible on the page, and
   - the matching product in the JavaScript items list (name and price).
   Keep each product's id the same in both places.
5. Change @yourhandle and add your actual delivery, returns and exchange policy.
6. Test the WhatsApp button before sharing the site.

PUBLISH FREE WITH GITHUB PAGES
------------------------------
1. Make a GitHub account at https://github.com/ if you don't have one.
2. Create a new PUBLIC repository named:
       YOUR-GITHUB-USERNAME.github.io
   Replace YOUR-GITHUB-USERNAME with your actual GitHub username.
3. In the repository, choose Add file > Upload files.
4. Upload index.html from this folder and commit the changes.
5. Open repository Settings > Pages.
6. Under Build and deployment, choose "Deploy from a branch".
7. Choose branch "main" and folder "/ (root)", then Save.
8. Wait a few minutes (sometimes up to 10 minutes), then visit:
       https://YOUR-GITHUB-USERNAME.github.io
9. Test it on your phone. Add this URL to your Instagram profile's Links section.

IMPORTANT
---------
- GitHub Pages publishes your site publicly. Do not upload private customer data or passwords.
- This is a static catalogue and WhatsApp order-request website, not a payment gateway.
- Customers send their order request to you in WhatsApp. You must confirm stock, shipping cost,
  payment method and delivery before treating an order as confirmed.
- The sample products/prices are placeholders. Do not advertise them as real inventory.
- Free hosting does not mean a custom domain name is included. A github.io address is free.
